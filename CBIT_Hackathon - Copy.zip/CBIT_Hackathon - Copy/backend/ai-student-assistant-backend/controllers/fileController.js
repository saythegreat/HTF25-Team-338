// controllers/fileController.js
import path from "path";

export const uploadFile = (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ success: false, message: "No file uploaded" });
    }

    // Return file info
    res.status(200).json({
      success: true,
      message: "File uploaded successfully",
      filename: req.file.filename,
      path: req.file.path
    });
  } catch (error) {
    res.status(500).json({ success: false, message: "Server Error", error: error.message });
  }
};
