// controllers/timetableController.js
import TimetableEvent from "../models/timetableEventModel.js";

// GET all events for logged-in user
export const getTimetable = async (req, res) => {
  try {
    const events = await TimetableEvent.find({ user: req.user._id });
    res.status(200).json(events);
  } catch (error) {
    res.status(500).json({ message: "Server Error", error: error.message });
  }
};

// POST a new event
export const addTimetable = async (req, res) => {
  try {
    const { title, description, date } = req.body;
    if (!title || !date)
      return res.status(400).json({ message: "Title and Date are required" });

    const newEvent = await TimetableEvent.create({
      user: req.user._id,
      title,
      description,
      date,
    });

    res.status(201).json(newEvent);
  } catch (error) {
    res.status(500).json({ message: "Server Error", error: error.message });
  }
};

// PATCH event
export const updateTimetable = async (req, res) => {
  try {
    const event = await TimetableEvent.findById(req.params.id);
    if (!event) return res.status(404).json({ message: "Event not found" });

    if (event.user.toString() !== req.user._id.toString())
      return res.status(401).json({ message: "Not authorized" });

    const updatedEvent = await TimetableEvent.findByIdAndUpdate(
      req.params.id,
      req.body,
      { new: true }
    );
    res.status(200).json(updatedEvent);
  } catch (error) {
    res.status(500).json({ message: "Server Error", error: error.message });
  }
};

// DELETE event
export const deleteTimetable = async (req, res) => {
  try {
    const event = await TimetableEvent.findById(req.params.id);
    if (!event) return res.status(404).json({ message: "Event not found" });

    if (event.user.toString() !== req.user._id.toString())
      return res.status(401).json({ message: "Not authorized" });

    await event.remove();
    res.status(200).json({ message: "Event deleted" });
  } catch (error) {
    res.status(500).json({ message: "Server Error", error: error.message });
  }
};
