import Assignment from "../models/assignmentModel.js";

// @desc    Get all assignments for logged-in user
// @route   GET /api/assignments
// @access  Private
export const getAssignments = async (req, res) => {
  try {
    const assignments = await Assignment.find({ user: req.user._id });
    res.status(200).json(assignments);
  } catch (error) {
    res.status(500).json({ message: "Server Error", error: error.message });
  }
};

// @desc    Add a new assignment
// @route   POST /api/assignments
// @access  Private
export const addAssignment = async (req, res) => {
  try {
    const { title, description, dueDate } = req.body;

    if (!title || !dueDate) {
      return res.status(400).json({ message: "Title and Due Date are required" });
    }

    const newAssignment = await Assignment.create({
      user: req.user._id,
      title,
      description,
      dueDate,
    });

    res.status(201).json(newAssignment);
  } catch (error) {
    res.status(500).json({ message: "Server Error", error: error.message });
  }
};

// @desc    Update an assignment
// @route   PATCH /api/assignments/:id
// @access  Private
export const updateAssignment = async (req, res) => {
  try {
    const assignment = await Assignment.findById(req.params.id);

    if (!assignment) {
      return res.status(404).json({ message: "Assignment not found" });
    }

    // Ensure user owns the assignment
    if (assignment.user.toString() !== req.user._id.toString()) {
      return res.status(401).json({ message: "Not authorized" });
    }

    const updatedAssignment = await Assignment.findByIdAndUpdate(
      req.params.id,
      req.body,
      { new: true }
    );

    res.status(200).json(updatedAssignment);
  } catch (error) {
    res.status(500).json({ message: "Server Error", error: error.message });
  }
};
