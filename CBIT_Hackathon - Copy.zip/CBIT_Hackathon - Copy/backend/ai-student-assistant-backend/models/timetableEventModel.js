// models/timetableEventModel.js
import mongoose from "mongoose";

const timetableEventSchema = new mongoose.Schema(
  {
    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: true,
    },
    title: { type: String, required: true },
    description: { type: String },
    startTime: { type: Date, required: true },
    endTime: { type: Date, required: true },
  },
  {
    timestamps: true,
  }
);

const TimetableEvent = mongoose.model("TimetableEvent", timetableEventSchema);

export default TimetableEvent;
