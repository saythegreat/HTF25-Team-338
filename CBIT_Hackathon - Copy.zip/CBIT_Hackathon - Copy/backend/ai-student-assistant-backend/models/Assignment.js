import mongoose from "mongoose";

const assignmentSchema = new mongoose.Schema({
  userId: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
  title: String,
  dueDate: Date,
  status: { type: String, default: "Pending" },
  priority: { type: String, default: "Normal" },
  notes: String,
});

export default mongoose.model("Assignment", assignmentSchema);
