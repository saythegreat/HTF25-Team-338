import mongoose from "mongoose";

const timetableSchema = new mongoose.Schema({
  userId: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
  title: String,
  dayOfWeek: String,
  startTime: String,
  endTime: String,
  color: String,
  location: String,
});

export default mongoose.model("TimetableEvent", timetableSchema);
